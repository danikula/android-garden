package com.danikula.android.garden.ui.validation;

public interface Validator {

    boolean validate(String value);
}