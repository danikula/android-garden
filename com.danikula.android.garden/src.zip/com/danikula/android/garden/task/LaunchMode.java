package com.danikula.android.garden.task;

public enum LaunchMode {

    SKIP_IF_RUNNING, ALWAYS_NEW, CANCEL_PREVIOUS

}
