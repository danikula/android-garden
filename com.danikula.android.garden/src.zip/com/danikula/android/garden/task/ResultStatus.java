package com.danikula.android.garden.task;

/* package private */enum ResultStatus {

    SUCCESS, FAIL, CANCEL

}
